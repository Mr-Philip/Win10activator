# Activate Windows 10 Pro

This script requires you to have a non-activated version of Windows 10 Pro installed on your machine. 

The script will not upgrade your current version, you have to download and install Windows 10 pro then use this script for it to work.

The script enters in a valid (but already used) Windows 10 license code, it then replaces the Windows key management server with a different server that will always return "valid" on an invalid key. 

There is no risk with this script; should the kms server go down, there are plenty of other servers to choose from: https://gist.github.com/vikassaini01/802ebf2b445154692d103cb04fd2bb9b
